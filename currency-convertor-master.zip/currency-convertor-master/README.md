# currency-convertor
to run this file you need to have jsoup api library.
Source for the info of currency value is provided by www.unitconverters.net . 
This program is made using eclipse.

